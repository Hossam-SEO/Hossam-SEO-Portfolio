'use strict';



// element toggle function
const elementToggleFunc = function (elem) { elem.classList.toggle("active"); }



// sidebar variables
const sidebar = document.querySelector("[data-sidebar]");
const sidebarBtn = document.querySelector("[data-sidebar-btn]");

// sidebar toggle functionality for mobile
sidebarBtn.addEventListener("click", function () { elementToggleFunc(sidebar); });







// custom select variables
const select = document.querySelector("[data-select]");
const selectItems = document.querySelectorAll("[data-select-item]");
const selectValue = document.querySelector("[data-selecct-value]");
const filterBtn = document.querySelectorAll("[data-filter-btn]");

select.addEventListener("click", function () { elementToggleFunc(this); });

// add event in all select items
for (let i = 0; i < selectItems.length; i++) {
  selectItems[i].addEventListener("click", function () {

    let selectedValue = this.innerText.toLowerCase();
    selectValue.innerText = this.innerText;
    elementToggleFunc(select);
    filterFunc(selectedValue);

  });
}

// filter variables
const filterItems = document.querySelectorAll("[data-filter-item]");

const filterFunc = function (selectedValue) {

  for (let i = 0; i < filterItems.length; i++) {

    if (selectedValue === "all") {
      filterItems[i].classList.add("active");
    } else if (selectedValue === filterItems[i].dataset.category) {
      filterItems[i].classList.add("active");
    } else {
      filterItems[i].classList.remove("active");
    }

  }

}

// add event in all filter button items for large screen
let lastClickedBtn = filterBtn[0];

for (let i = 0; i < filterBtn.length; i++) {

  filterBtn[i].addEventListener("click", function () {

    let selectedValue = this.innerText.toLowerCase();
    selectValue.innerText = this.innerText;
    filterFunc(selectedValue);

    lastClickedBtn.classList.remove("active");
    this.classList.add("active");
    lastClickedBtn = this;

  });

}







// page navigation variables
const navigationLinks = document.querySelectorAll("[data-nav-link]");
const pages = document.querySelectorAll("[data-page]");

// add event to all nav link
for (let i = 0; i < navigationLinks.length; i++) {
  navigationLinks[i].addEventListener("click", function () {

    for (let i = 0; i < pages.length; i++) {
      if (this.innerHTML.toLowerCase() === pages[i].dataset.page) {
        pages[i].classList.add("active");
        navigationLinks[i].classList.add("active");
        window.scrollTo(0, 0);
      } else {
        pages[i].classList.remove("active");
        navigationLinks[i].classList.remove("active");
      }
    }

  });
}


// SEO Lightbox
const lightbox = document.getElementById("seo-lightbox");
const lightboxImg = document.getElementById("seo-lightbox-img");
const lightboxTitle = document.getElementById("seo-lightbox-title");
const lightboxLabel = document.getElementById("seo-lightbox-label");
const lightboxClose = document.getElementById("seo-lightbox-close");
const lightboxNav = document.getElementById("seo-lightbox-nav");
const prevBtn = document.getElementById("seo-prev-btn");
const nextBtn = document.getElementById("seo-next-btn");

let currentImages = [];
let currentIndex = 0;

function showLightboxImage(index) {
  currentIndex = index;
  lightboxImg.src = currentImages[index].src;
  lightboxLabel.textContent = currentImages[index].label;
  prevBtn.style.opacity = index === 0 ? "0.3" : "1";
  prevBtn.style.pointerEvents = index === 0 ? "none" : "auto";
  nextBtn.style.opacity = index === currentImages.length - 1 ? "0.3" : "1";
  nextBtn.style.pointerEvents = index === currentImages.length - 1 ? "none" : "auto";
}

document.querySelectorAll(".seo-lightbox-trigger").forEach(function(trigger) {
  trigger.addEventListener("click", function(e) {
    e.preventDefault();
    const startImg = this.dataset.start;
    const endImg = this.dataset.img;

    if (startImg) {
      currentImages = [
        { src: startImg, label: "START" },
        { src: endImg,   label: "END"   }
      ];
      lightboxNav.style.display = "flex";
    } else {
      currentImages = [{ src: endImg, label: "" }];
      lightboxNav.style.display = "none";
    }

    lightboxTitle.textContent = this.dataset.title;
    lightbox.style.display = "flex";
    showLightboxImage(0);
  });
});

prevBtn.addEventListener("click", function() {
  if (currentIndex > 0) showLightboxImage(currentIndex - 1);
});

nextBtn.addEventListener("click", function() {
  if (currentIndex < currentImages.length - 1) showLightboxImage(currentIndex + 1);
});

lightboxClose.addEventListener("click", function() {
  lightbox.style.display = "none";
  lightboxImg.src = "";
});

lightbox.addEventListener("click", function(e) {
  if (e.target === lightbox) {
    lightbox.style.display = "none";
    lightboxImg.src = "";
  }
});
